/**
 * OW2 FraSCAti Examples : Fscript reconfiguration
 * Copyright (C) 2008-2010 INRIA, University of Lille 1
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Christophe Demarey
 */
package org.ow2.frascati.examples.reconfig.converter;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

import org.osoa.sca.annotations.Service;

/**
 * A basic currency converter. 
 */
@Service
public interface CurrencyConverter
{
    /**
     * Converts Euros to Dollars.
     * 
     * @param value the amount of euros to convert.
     */
    @GET
    @Path("/euro2dollar")
    double euroToDollar(@FormParam("value") double value);
    /**
     * Converts Dollars to Euros.
     * 
     * @param value the amount of dollars to convert.
     */
    @GET
    @Path("/dollar2euro")
    double dollarToEuro(@FormParam("value") double value);
    /**
     * Converts Euros to Pesos.
     * 
     * @param value the amount of euros to convert.
     */
    @GET
    @Path("/euro2peso")
    double euroToPeso(@FormParam("value") double value);
    /**
     * Converts Pesos to Euros.
     * 
     * @param value the amount of dollars to convert.
     */
    @GET
    @Path("/peso2euro")
    double pesoToEuro(@FormParam("value") double value);
}
