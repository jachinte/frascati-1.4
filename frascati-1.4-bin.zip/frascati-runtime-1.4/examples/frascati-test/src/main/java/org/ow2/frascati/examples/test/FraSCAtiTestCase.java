/**
 * OW2 FraSCAti Examples: Testing module
 * Copyright (C) 2009-2010 INRIA, University of Lille 1
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Contact: frascati@ow2.org
 *
 * Author: Nicolas Dolet
 *
 * Contributor(s): Philippe Merle
 */

package org.ow2.frascati.examples.test;

import org.junit.After;
import org.junit.Before;

import org.objectweb.fractal.api.Component;

import org.ow2.frascati.FraSCAti;
import org.ow2.frascati.util.FrascatiException;

/**
 * Abstract class for testing SCA applications with FraSCAti
 * 
 */
public abstract class FraSCAtiTestCase
{

  private FraSCAti frascati;

  /**
   * The SCA composite to test
   */
  private Component scaComposite;

  /**
   * Load a composite
   * 
   * @param name
   *          the composite name
   * @throws FrascatiException 
   */
  @Before
  public final void loadComposite() throws FrascatiException
  {
    String compositeName = getComposite();
    System.out.println("Loading SCA composite '" + compositeName + "'...");
    frascati = FraSCAti.newFraSCAti();
    scaComposite = frascati.getComposite(compositeName);
  }

  /**
   * Get a service on the SCA composite
   * 
   * @param <T>
   *          the class type for the return
   * @param serviceName
   *          the name of the service
   * @return the service named <code>serviceName</code> or null
   */
  protected final <T> T getService(Class<T> cl, String serviceName)
  {
    System.out.println("Getting SCA service '" + serviceName + "'...");
    try {
      return frascati.getService(scaComposite, serviceName, cl);
    } catch (Exception e) {
      System.err.println("No such SCA service: " + serviceName);
      return null;
    }
  }

  /**
   * Close the SCA domain
   * 
   * @throws IllegalLifeCycleException
   *           if the domain cannot be closed
   * @throws NoSuchInterfaceException
   *           if the lifecycle controller of the component is not found
   */
  @After
  public final void close() throws FrascatiException
  {
    if(scaComposite != null) {
      frascati.close(scaComposite);
    }
  }

  // ---------------------------------------------------------------------------
  // Abstract methods
  // ---------------------------------------------------------------------------

  /**
   * Return the name of the composite to test.
   * 
   * @return the name of the composite to test.
   */
  public abstract String getComposite();

}
